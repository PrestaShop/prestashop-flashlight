<?php

namespace PrestaShop\Module\PsAlsace\Service;

class PsAlsaceService
{
    public function __construct()
    {
    }

    public function pollDoYouLikeAlsace()
    {
        return true;
    }

    public function pollDoYouLikeLorraine()
    {
        return;
    }
}
